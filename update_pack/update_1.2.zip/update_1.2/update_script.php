<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();



	//add column on movie table
	$movie_fields = array(
	    'trailer_url' => array('type' => 'LONGTEXT', 'null'  => TRUE)
	);
	$CI->dbforge->add_column('movie', $movie_fields);

	//add column on movie table
	$series_fields = array(
	    'trailer_url' => array('type' => 'LONGTEXT', 'null'  => TRUE)
	);
	$CI->dbforge->add_column('series', $series_fields);
?>
